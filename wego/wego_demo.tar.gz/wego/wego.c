/*
************************************************************************
*** wego - an easy library for simple SMP/multithreading in C
************************************************************************
* $Header: /home/mark/CVSROOT/wego/wego.c,v 1.2 2006/12/16 23:39:21 mark Exp $
*/

#include <malloc.h>
#include <pthread.h>
#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <stdlib.h>

#include "wego.h"

#if 0
#define DEBUG(x) { if (wego_debug) printf x ; }
#define DEBUG(x) { printf x ; }
#endif
#define DEBUG(x) { }

/************************************************************************/

/*
* information about a single task
*/
struct wego_task
	{
	void	(*function)();		/* function to call */
	void *	parameter_struct;	/* parameters from user */
	int	parameter_struct_size;
	void *	result_struct;		/* place to store return values */
	int	result_struct_size;


	int	flags;
#define WEGO_TASK_ALLOC_RESULT 	1

	struct wego_group *group;	/* what group are we in? */

	struct wego_task *q_next;	/* next in queue of all pending tasks */

	struct wego_task *g_next;	/* next in list of all tasks in group */

	/*
	* fields for applications waiting for our result
	*/
	pthread_mutex_t		finished_semaphore;
	pthread_cond_t		finished_condition;
	int			finished_flag;
	int			reportable_flag;
	int			ever_reported;
	int			running_flag;

	};

/************************************************************************/

/*
* group of tasks
*/
struct wego_group
	{
	pthread_mutex_t		group_semaphore;
	pthread_cond_t		group_condition;
	struct wego_task *task_list;
	int	task_count;
	};


/************************************************************************/

/*
* Thread management variables
* You must have thread_take semaphore to access any of these variables:
*/

	/*
	* thread synchronization for these variables
	*/
	static pthread_cond_t	thread_take_condition = PTHREAD_COND_INITIALIZER;
	static pthread_mutex_t	thread_take = PTHREAD_MUTEX_INITIALIZER;

	struct threadrunner
		{
		int			main;		/* main program */
		int			running;	/* using a cpu */
		int			available;	/* available to run a task */
		int			waiting;	/* waiting to continue */
		int			thread_id;	/* small integer thread number */
		pthread_cond_t		condition;
		pthread_mutex_t		semaphore;
		struct threadrunner *	next;
		};

	static struct threadrunner 	main_thread = { 1, 1, 0, 0, 0 };
	static struct threadrunner *	all_threads = &main_thread;

	static pthread_cond_t		thread_startup_condition = PTHREAD_COND_INITIALIZER;
	static pthread_mutex_t		thread_startup_lock = PTHREAD_MUTEX_INITIALIZER;

	/*
	* queue of all tasks waiting to be run
	*/
	static struct wego_task *queued_tasks = NULL;

/************************************************************************/

/*
* forward declarations
*/
static void want_to_sleep();
static struct wego_task * want_to_run();
void wego_schedule();
static void *wego_threadrunner(void *thread_parameter);



/************************************************************************/

pthread_key_t threadrunner_key;

#define TID ( ((struct threadrunner *)pthread_getspecific(threadrunner_key))->thread_id )

/************************************************************************/

/*
* This is the maximum number of threads that can be running concurrently.
* You can set this from your main program before you call any wego
* functions.  If you do not, we use the value from the environment variable 
* WEGO_THREADS.  Otherwise, the default is 3.
*
* If you change this value after starting some threads, the results are
* undefined.
*/
static int max_threads = 0;


/************************************************************************/


/************************************************************************/

void wego_max_threads(int max)
{
	max_threads = max;
}

/************************************************************************/

/************************************************************************/

/************************************************************************/


/*----------------------------------------------------------------------*/


/*
* Create a new task.
*
** There are no concurrency issues until we enter the task into the
** common data structures.
*/

struct wego_task *
	wego_run(struct wego_group *group, void (*function)(), 
		void *parameter_struct, size_t parameter_struct_size, 
		void *result_struct, size_t result_struct_size
	)
{
	struct wego_task *r;

	DEBUG(("wego_run in %d\n",TID))

	/*
	* create the struct
	*/
	r = malloc(sizeof(struct wego_task));
	if (!r)
		return NULL;

	/*
	* all fields initialized to 0
	*/
	memset(r,0,sizeof(*r));

	pthread_mutex_init(&r->finished_semaphore, NULL);
	pthread_cond_init(&r->finished_condition, NULL);

	r->function = function;

	if (parameter_struct)
		{
		r->parameter_struct = malloc(parameter_struct_size);
		if (! r->parameter_struct)
			{
			free(r);
			return NULL;
			}
		memcpy(r->parameter_struct,parameter_struct,parameter_struct_size);
		}
	else
		r->parameter_struct = NULL;
	r->parameter_struct_size = parameter_struct_size;

	if (result_struct)
		r->result_struct = result_struct;
	else
		{
		r->result_struct = malloc(result_struct_size);
		if (!r->result_struct)
			{
			free(r->parameter_struct);
			free(r);
			return NULL;
			}
		r->flags |= WEGO_TASK_ALLOC_RESULT;
		}
	r->result_struct_size = result_struct_size;

	r->group = group;

	/*
	* add it to the list of everything to be done
	*/
	pthread_mutex_lock(&thread_take);
	r->q_next = queued_tasks;
	queued_tasks = r;
	pthread_mutex_unlock(&thread_take);

	/*
	* if it is part of a group, add it to the group.
	*/
	if (group)
		{
		pthread_mutex_lock(&group->group_semaphore);
		group->task_count++;
		r->g_next = group->task_list;
		group->task_list = r;
		pthread_mutex_unlock(&group->group_semaphore);
		}

	DEBUG(("wego_run: - schedule -\n"))
	wego_schedule();
	return r;
}

/************************************************************************/

/*
* create a group
*
** There are no concurrency issues until after we return the data structure.
*/

struct wego_group * wego_new_group()
{
	struct wego_group *g;
	g = malloc(sizeof(*g));
	if (!g)
		return NULL;
	memset(g,0,sizeof(*g));
	pthread_mutex_init(&g->group_semaphore, NULL);
	pthread_cond_init(&g->group_condition, NULL);
	DEBUG(("wego_new_group return %x\n",(int)g))
	return g;
}

/************************************************************************/

/*
* extract the result of a task
*
* t->finished_semaphore controls access to the data about whether a task
* is finished.
*	t->finished_flag means it is finished
*	t->reportable means it is eligible to be reported by wego_fin()
*	t->ever_reported means the results have been reported at least once
*
*/

void * 
	wego_result(struct wego_task *t)
{
	void *r;

	pthread_mutex_lock(&t->finished_semaphore);
	DEBUG(("wego_result in %d\n",TID))
	while (! t->finished_flag)
		{
		want_to_sleep();
		pthread_cond_wait( &t->finished_condition, &t->finished_semaphore );
		want_to_run();
		}
	t->reportable_flag = 0;
	t->ever_reported = 1;
	r = t->result_struct;
	DEBUG(("wego_result in %d done\n",TID))
	pthread_mutex_unlock(&t->finished_semaphore);
	return r;
}

/************************************************************************/

struct wego_task *
	wego_fin(struct wego_group *group)
{
	struct wego_task *t;
	int reported_already;

	DEBUG(("wego_fin enter\n"))

	reported_already=0;

	/*
	* We have to lock the group semaphore while we examine the list
	* of all tasks for one we have not reported on yet.
	*
	* We have to lock the finished semaphore while we examine an
	* individual task.
	*
	* There is no deadlock because this is the only place in the
	* library where we lock BOTH a group semaphore and a finished semaphore.
	*/

	for (;;)
		{
		pthread_mutex_lock(&group->group_semaphore);
		/*
		* Look for any one task that is reportable.
		*/
		for (t=group->task_list; t; t=t->g_next)
			{
			pthread_mutex_lock(&t->finished_semaphore);
			if (t->reportable_flag)
				{
				/*
				* found one - report it.
				*/
				t->reportable_flag = 0;
				t->ever_reported = 1;
				pthread_mutex_unlock(&t->finished_semaphore);
				pthread_mutex_unlock(&group->group_semaphore);
				DEBUG(("wego_fin return data\n"))
				return t;
				}
			if (t->ever_reported)
				reported_already++;
			pthread_mutex_unlock(&t->finished_semaphore);
			}

		/*
		* If all tasks on the list have been reported, return NULL.
		*/
		if (group->task_count == reported_already)
			{
			pthread_mutex_unlock(&group->group_semaphore);
			DEBUG(("wego_fin return NULL\n"))
			want_to_run();
			return NULL;
			}
		pthread_mutex_unlock(&group->group_semaphore);


		/*
		* didn't find any reportable. sleep and try again.
		*/
		want_to_sleep();
		pthread_mutex_lock(&group->group_semaphore);
		pthread_cond_wait( &group->group_condition, &group->group_semaphore );
		pthread_mutex_unlock(&group->group_semaphore);
		want_to_run();

		}
}

/************************************************************************/

static void want_to_sleep()
{
	struct threadrunner *t;
	pthread_mutex_lock(&thread_take);
	DEBUG(("want_to_sleep in %d\n",TID))
	t = pthread_getspecific(threadrunner_key);
	t->running = 0;
	t->waiting = 1;
	pthread_mutex_unlock(&thread_take);
	DEBUG(("want_to_sleep: - schedule -\n"))
	wego_schedule();
}

/************************************************************************/

static struct wego_task * want_to_run()
{
	struct wego_task *w;
	struct threadrunner *t;

	t = pthread_getspecific(threadrunner_key);
	DEBUG(("want_to_run in %d\n",TID))

	pthread_mutex_lock(&thread_take);
	while (! t->running)
		{
		DEBUG(("want_to_run in %d waiting\n",TID))
		pthread_cond_wait(&thread_take_condition, &thread_take);
		}
	DEBUG(("want_to_run in %d running\n",TID))
	t->waiting = 0;
	pthread_mutex_unlock(&thread_take);

	return w;
}


/************************************************************************/

/*
* This is the main program of each thread.
*/

static void *wego_threadrunner(void *thread_parameter)
{
	struct threadrunner *t;

	pthread_mutex_lock(&thread_startup_lock);
	t = thread_parameter;
	pthread_setspecific(threadrunner_key, thread_parameter);

	t->running = 0;
	t->available = 1;

	pthread_cond_signal(&thread_startup_condition);
	pthread_mutex_unlock(&thread_startup_lock);


	DEBUG(("threadrunner in %d: startup complete\n",TID))

	/*
	* Wait for: we can run a task
	*/
	for (;;)
		{
		struct wego_task *w;
		struct wego_group *g;

		DEBUG(("					threadrunner top of loop\n"))

		/*
		* set our thread status to show that:
		* - we are not using CPU
		* - we are not waiting to run
		* - we are available to run a task
		*/
		pthread_mutex_lock(&thread_take);
		t->running = 0;
		t->available = 1;
		t->waiting = 0;
		pthread_mutex_unlock(&thread_take);

		/*
		* make sure the scheduler thinks about our new state
		*/
		wego_schedule();

		/*
		* sleep until the scheduler marks us as running.  the scheduler
		* set running to 1, available to 0.
		*/
		pthread_mutex_lock(&t->semaphore);
		while (t->running == 0)
			pthread_cond_wait(&t->condition, &t->semaphore);
		pthread_mutex_unlock(&t->semaphore);

		/*
		* fetch a task from the queue.  it is possible that the
		* queue may be exhausted now and then.  If so, go back to sleep.
		*/
		pthread_mutex_lock(&thread_take);
		w = queued_tasks;
		if (!w)
			{
			DEBUG(("					threadrunner no more tasks\n"))
			pthread_mutex_unlock(&thread_take);
			continue;
			}
		queued_tasks = queued_tasks -> q_next;
		pthread_mutex_unlock(&thread_take);

		/*
		* execute the user's function
		*/
		w->function(w, w->parameter_struct, w->result_struct);

		/*
		* Flag the task as finished.
		* Wake up anybody who is waiting for the results.
		*/
		pthread_mutex_lock(&w->finished_semaphore);
		w->finished_flag = 1;
		w->reportable_flag = 1;
		pthread_cond_signal(&w->finished_condition);
		pthread_mutex_unlock(&w->finished_semaphore);

		/*
		* If the task was part of a group, wake up anybody
		* who is waiting for group results.
		*/
		g=w->group;
		if (g)
			{
			pthread_mutex_lock(&g->group_semaphore);
			pthread_cond_signal(&g->group_condition);
			pthread_mutex_unlock(&g->group_semaphore);
			}

		}
	/* 
	* We never get here.  
	* Threads never go away.  If we don't need a thread, it
	* just sits idle.
	*/
}



/************************************************************************/

static void wego_new_thread()
{
        pthread_t thread;
        int n;
	struct threadrunner *t;
	static int thread_id = 1;

	DEBUG(("wego_new_thread in %d\n",TID))

	t = malloc(sizeof(*t));
	memset(t,0,sizeof(*t));
	t->running = 0;
	t->available = 1;
	t->main = 0;
	t->thread_id = thread_id++;
	t->next = all_threads;
	pthread_cond_init(&t->condition,NULL);
	pthread_mutex_init(&t->semaphore,NULL);
	all_threads = t;

	pthread_mutex_lock(&thread_startup_lock);
        n = pthread_create(&thread, NULL, wego_threadrunner, (void *)t);
	pthread_cond_wait(&thread_startup_condition, &thread_startup_lock);
	pthread_mutex_unlock(&thread_startup_lock);
}


void wakeup_threadrunner(struct threadrunner *t)
{
	/*
	* this function is used by wego_schedule() to wake up a specific
	* thread that is waiting in threadrunner().
	*/
	pthread_mutex_lock(&t->semaphore);
	pthread_cond_signal(&t->condition);
	pthread_mutex_unlock(&t->semaphore);
}

void wego_schedule()
{
	struct threadrunner *t;
	int running = 0;
	int num_available = 0;

	pthread_mutex_lock(&thread_take);
	DEBUG(("\n\nwego_schedule in %d\n",TID))

	/*
	* See how many threads are running, how many are available.  I consider
	* counting them here to be more reliable than ++/-- all over the place.
	* Typically, I expect a small number of threads, so there is little
	* overhead here.
	*/
	for (t = all_threads; t; t=t->next)
		{
		DEBUG(("wego_schedule: %d run %d available %d waiting %d\n",t->thread_id, t->running, t->available, t->waiting))
		if (t->running)
			running++;
		if (t->available)
			num_available++;
		}

	/*
	* Make sure we have enough threads to keep all the CPUs busy.  Sometimes
	* this creates more threads than we need, but that is ok.  They will just
	* sit idle.
	*/
	while (num_available + running <= max_threads)
		{
		DEBUG(("wego_schedule: available %d running %d < max %d\n", num_available , running , max_threads) )
		wego_new_thread();
		num_available++;
		}

	DEBUG(("wego_schedule: running %d available %d\n",running,num_available))

	/*
	* First priority is to threads that are waiting for results.  These are
	* in the middle of their execution.
	*/
	for (t=all_threads; t; t=t->next)
		{
		if (running >= max_threads)
			break;
		if (t->waiting)
			{
			DEBUG(("wego_schedule: waking %d\n",t->thread_id))
			t->waiting=0;
			t->running=1;
			/* should we try to wake anybody here? */
			running++;
			}
		}

	/*
	* If we still do not have all the CPUs busy, look for new tasks.
	* If there are any, wake up threads to start running them.
	*/
	if (queued_tasks)
		{
		DEBUG(("wego_schedule: look for thread starters\n"))
		for (t=all_threads; t; t=t->next)
			{
			if (t->available)
				{
				DEBUG(("wego_schedule: waking available %d\n",t->thread_id))
				t->available = 0;
				t->running=1;
				wakeup_threadrunner(t);
				running++;
				}
			}
		}

	DEBUG(("wego_schedule in %d done\n\n\n",TID))
	/*
	* this broadcast will wake up everybody who is sleeping in
	* want_to_run().  This is too many, but only the ones 
	*/
	pthread_cond_broadcast(&thread_take_condition);
	pthread_mutex_unlock(&thread_take);
}

/************************************************************************/

void wego_init()
{
	int n;
	static int init = 0;
	if (init)
		return;
	init = 1;
	n = pthread_key_create(&threadrunner_key, NULL );
	if (n < 0)
		perror("pthread_key_create");
	pthread_setspecific(threadrunner_key, &main_thread);
}

/************************************************************************/

/* 
* You wish these two functions were implemented.  They will come later.
*
* Leaking this memory is undesirable, but not so bad for initial testing.
*/
void wego_free_task( struct wego_task *task )
{
}

void wego_free_group( struct wego_group *group )
{
}

/************************************************************************/

/*
* This function is not called from anywhere.  You can use it in gdb
* with "print dump_threads()"
*/

int dump_threads()
{
	struct threadrunner *t;
	for (t = all_threads; t; t=t->next)
		{
		printf("%d\t",t->thread_id);
		printf("run %d avail %d wait %d main %d\n",t->running, t->available, t->waiting, t->main);
		}
return 0;
}

/*
************************************************************************
*** end of file
************************************************************************
*/
