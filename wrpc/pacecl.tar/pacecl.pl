#!./perl
# ^------ Change this to point to your perl with Aceclient extensions

use Aceclient;
# this script will fail at this point unless PERL5LIB is set
# to point to (perl install directory)/lib

die "Usage: $0 <host> <rpcpn>\n" unless @ARGV == 2;
$server = shift(@ARGV);
$rpcpn = shift(@ARGV);

# usage openServer(servername, rpcpn, timeout
# the timeout is the time the client will wait for a
# response in seconds
die "Can't connect to server $server at rpcpn $rpcpn!!!\nI will take my own life now.\n" unless ($ace_handle = openServer($server, $rpcpn, 1000));

print "Connection succeeded - you may begin querying the server.\n";
print "\nperlace> ";

while(<>) {
    chop;
    if (/^q/) {
	closeServer($ace_handle);
	print "A bientot\n";
	exit;
    }
    print "$_\n";

# usage askServer(acehandle, query, chunksize_in_kbytes-(not implemented))
# chunksize is the maximum number of kB that you would like the
# server to return.  The server may limit chunksize also so the client
# may get less than this value back
    ($status, $answer) = askServer($ace_handle, $_, 100);
    if ($status != 0) {
	print "Status: $status";
    }
    if ($answer) {
	print $answer;
    } else {
	print "The query returned no results.\n";
    }
    undef $answer;
    undef $_;
    print "\nperlace> ";
}
closeServer($ace_handle);
